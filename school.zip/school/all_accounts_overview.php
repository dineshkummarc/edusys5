<?php
session_start();
if(isset($_SESSION['lkg_uname'])&&!empty($_SESSION['lkg_pass'])&&!empty($_SESSION['academic_year']))
{
$cur_academic_year = $_SESSION['academic_year'];

	require("header.php");
	require("connection.php");
	error_reporting("0");
	$from=$_GET["from"];
	$to=$_GET["to"];
	
	?>
	<head>
<script>
function printDiv(income) {
     var printContents = document.getElementById('income').innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
</script>
</head>

			<div class="container">
			<div class="row">
			<div class="col-md-2">
			</div>
			<div class="col-md-8">
			
  
				<?php
			///////////////////////////////////////////////////////////////////////////////////////////////////////
			$sql_est="select sum(adm_fee) as tot_est_fee from student_fee where academic_year='".$cur_academic_year."'";
			$result_est=mysqli_query($conn,$sql_est);
			if($row_est=mysqli_fetch_array($result_est,MYSQLI_ASSOC))
			{
				$tot_est_fee=$row_est["tot_est_fee"];
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////
			$sql_adm="select sum(adm_fee) as tot_adm_fee from student_adm_fee where academic_year='".$cur_academic_year."'";
			$result_adm=mysqli_query($conn,$sql_adm);
			if($row_adm=mysqli_fetch_array($result_adm,MYSQLI_ASSOC))
			{
				$tot_adm_fee=$row_adm["tot_adm_fee"];
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////
			$sql_cca="select sum(adm_fee) as tot_cca_fee from student_cca_fee where academic_year='".$cur_academic_year."'";
			$result_cca=mysqli_query($conn,$sql_cca);
			if($row_cca=mysqli_fetch_array($result_cca,MYSQLI_ASSOC))
			{
				$tot_cca_fee=$row_cca["tot_cca_fee"];
			}
			
			/////////////////////////////////////////////////////////////////////////////////////////////////////
			$sql_books="select sum(adm_fee) as tot_books_fee from student_books_fee where academic_year='".$cur_academic_year."'";
			$result_books=mysqli_query($conn,$sql_books);
			if($row_books=mysqli_fetch_array($result_books,MYSQLI_ASSOC))
			{
				$tot_books_fee=$row_books["tot_books_fee"];
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////
			$sql_uni="select sum(adm_fee) as tot_uni_fee from student_uniform_fee where academic_year='".$cur_academic_year."'";
			$result_uni=mysqli_query($conn,$sql_uni);
			if($row_uni=mysqli_fetch_array($result_uni,MYSQLI_ASSOC))
			{
				$tot_uni_fee=$row_adm["tot_uni_fee"];
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////
			$sql_shoe="select sum(adm_fee) as tot_shoe_fee from student_shoe_fee where academic_year='".$cur_academic_year."'";
			$result_shoe=mysqli_query($conn,$sql_shoe);
			if($row_shoe=mysqli_fetch_array($result_shoe,MYSQLI_ASSOC))
			{
				$tot_shoe_fee=$row_shoe["tot_shoe_fee"];
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////
			$sql_soft="select sum(adm_fee) as tot_soft_fee from student_software_fee where academic_year='".$cur_academic_year."'";
			$result_soft=mysqli_query($conn,$sql_soft);
			if($row_soft=mysqli_fetch_array($result_soft,MYSQLI_ASSOC))
			{
				$tot_soft_fee=$row_soft["tot_soft_fee"];
			}
			/////////////////////////////////////////////////////////////////////////////////////////////////////
			$sql_van="select sum(van_fee) as tot_van_fee from student_van_fee where academic_year='".$cur_academic_year."'";
			$result_van=mysqli_query($conn,$sql_van);
			if($row_van=mysqli_fetch_array($result_van,MYSQLI_ASSOC))
			{
				$tot_van_fee=$row_van["tot_van_fee"];
			}
			////////////////////////////////////////////////////////////////////////////////
			
			
			/////////////////////////////////////Start of total income ////////////////////////////////////////////
			
			$sql_tot="select sum(amount) as total_amount from income where academic_year='".$cur_academic_year."'";
		   
			//var_dump($sql_amount);
			$result_tot=mysqli_query($conn,$sql_tot);
			if($row_tot=mysqli_fetch_array($result_tot,MYSQLI_ASSOC))
			{
			
			$total_income= $row_tot["total_amount"];
			}
			/////////////////////////////////////End of total income ////////////////////////////////////////////





			/////////////////////////////////////Start of total Expense ////////////////////////////////////////////
			
			$sql_exp="select sum(amount) as total_amount from expense where academic_year='".$cur_academic_year."'";
		   
			//var_dump($sql_exp);
			$result_exp=mysqli_query($conn,$sql_exp);
			if($row_exp=mysqli_fetch_array($result_exp,MYSQLI_ASSOC))
			{
			
			$total_expense= $row_exp["total_amount"];
			}
			/////////////////////////////////////End of total Expense ////////////////////////////////////////////
			?>			
					
			<div class="row">
				<div class="col-sm-12"><br>
				<center><h1 style="font-weight:bold;color:red;text-transform: uppercase;text-decoration:underline;">Total Accounts Overview</h1></center>
				
				<br>
				<div class="table-reponsive">
					<table class="table table-bordered">
						<tr style="background:yellow;color:black;font-weight:bold;padding:5px;">
							<th>CATEGORY</th>
							<th>AMOUNTS <?php echo $cur_academic_year;?></th>
						</tr>
						<tr style="background:green;color:white;font-weight:bold;padding:5px;">
							<td>School Fee</td>
							<td><?php echo $tot_est_fee;?></td>
						</tr>
						<tr style="background:green;color:white;font-weight:bold;padding:5px;">
							<td>RTE Fee</td>
							<td><?php echo $tot_adm_fee;?></td>
						</tr>
						<tr style="background:green;color:white;font-weight:bold;padding:5px;">
							<td>Staff Children Fee</td>
							<td><?php echo $tot_cca_fee;?></td>
						</tr>
						
						<tr style="background:green;color:white;font-weight:bold;padding:5px;">
							<td>Van Fee</td>
							<td><?php echo $tot_van_fee;?></td>
						</tr>
						
						<tr style="background:yellow;color:black;font-weight:bold;padding:5px;">
							<td>Total Fee Collected</td>
							<td><?php echo $tot_est_fee+$tot_adm_fee+$tot_cca_fee+$tot_van_fee;?></td>
						</tr>
						
						<tr style="background:green;color:white;font-weight:bold;padding:5px;">
							<td>Total Income</td>
							<td><?php echo $total_income;?></td>
						</tr>
						
						
						<tr style="background:yellow;color:black;font-weight:bold;padding:5px;">
							<td>Total Fee & Income</td>
							<td><?php echo $total_income+$tot_est_fee+$tot_adm_fee+$tot_cca_fee+$tot_van_fee;?></td>
						</tr>
						
						<tr style="background:red;color:white;font-weight:bold;padding:5px;">
							<td>Total Expense</td>
							<td><?php echo $total_expense;?></td>
						</tr>
						
						<tr style="background:blue;color:white;font-weight:bold;padding:5px;">
							<td>Balance</td>
							<td><?php echo ($tot_est_fee+$tot_adm_fee+$tot_cca_fee+$tot_van_fee+$total_income)-$total_expense;?></td>
						</tr>
						
					</table>				
				</div>
				 <button class="btn btn-success" onclick="goBack()">Go Back</button>
				</div>
			</div>
		
	</div> 
	<div class="col-md-2">
	</div>
	</div> 
	</div> 

	
	
<?php
			
}


else
{
header("Location:login.php");
}
?>  
