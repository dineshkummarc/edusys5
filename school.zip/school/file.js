var arr=[
['lkg',['a section','b section']],
['ukg',['a section']],
['first standard',['a section']]
];