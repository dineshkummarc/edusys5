	<option value="">Select Class</option>
			<option value="prekg">PreKG</option>
			<option value="lkg">LKG</option>
			<option value="ukg">UKG</option>
			 <option value="first standard">1st Standard</option>
				<option value="second standard">2nd Standard</option>
			  <option value="third standard">3rd Standard</option>
			  <option value="fourth standard">4th Standard</option>
			  <option value="fifth standard">5th Standard</option>
			  <option value="sixth standard">6th Standard</option>
			  <option value="seventh standard">7th Standard</option>
			  <option value="eighth standard">8th Standard</option>
			   <option value="ninth standard">9th Standard</option>
			  <option value="tenth standard">10th Standard</option>
			  <option value="first puc arts">1st PUC Arts</option>
			  <option value="first puc commerce">1st PUC Commerce</option>
			  <option value="first puc science">1st PUC Science</option>
			  <option value="second puc arts">2nd PUC Arts</option>
			  <option value="second puc commerce">2nd PUC Commerce</option>
			  <option value="second puc science">2nd PUC Science</option>
			  <option value="B.com 1st year">B.com 1st year</option>
			  <option value="B.com 2nd year">B.com 2nd year</option>
			  <option value="B.com 3rd year">B.com 3rd year</option>
			</select>
	  </div>	