<option value="kannada">Kannada</option>
<option value="lunch">Lunch Break</option>
<option value="english">English</option>
<option value="environmental studies">Environmental Studies</option>
<option value="drawings cca">Drawings CCA</option>
<option value="political science">Political Science</option>
<option value="economics">Economics</option>
<option value="business study">Business Study</option>
<option value="accountancy">Accountancy</option>
<option value="computer science">Computer Science</option>
<option value="history">History</option>
<option value="sociology">Sociology</option>
<option value="physics">Physics</option>
<option value="chemistry">Chemistry</option>
<option value="mathematics">Mathematics</option>
<option value="biology">Biology</option>
</select><br>